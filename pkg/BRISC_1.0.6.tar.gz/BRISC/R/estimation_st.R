BRISC_ST_estimation <- function(coords, Y, X = NULL, sigma.sq = 1, tau.sq = 0.1, phi = 1, nu = 1.5,
                                 gamma = 0.5, n.neighbors = 15, n_omp = 1, order = "Sum_coords",
                                 cov.model = "exponential", search.type = "tree", verbose = TRUE,
                                 eps = 2e-05, nugget_status = 1, ordering = NULL, neighbor = NULL, tol = 12
){
  ## Separable spatiotemporal NNGP x AR(1) MLE: Cov(Z) = sigma.sq * (R_t %x% R_s), fit on a
  ## full N (sites) x T (times) grid via the Kronecker shortcuts in overleaf/main.tex.
  N <- nrow(coords)

  if(!is.matrix(coords)){stop("error: coords must be an N-by-2 matrix of xy-coordinate locations")}
  if(ncol(coords) != 2 || nrow(coords) != N){
    stop("error: coords must have exactly two columns and N rows matching Y")
  }

  ## Y can be an N-by-T matrix, or the stacked vector vec(Y) itself (site index fastest,
  ## i.e. all N sites at t = 1, then all N sites at t = 2, ...); T is inferred from N.
  if(is.matrix(Y)){
    if(nrow(Y) != N){stop("error: nrow(Y) must equal nrow(coords)")}
    Tt <- ncol(Y)
  } else {
    if(!is.numeric(Y) || !is.null(dim(Y))){
      stop("error: Y must be either an N-by-T matrix or a numeric vector of length a multiple of N")
    }
    if(length(Y) %% N != 0){
      stop("error: length(Y) must be a multiple of nrow(coords) (Y is vec(Y), site index fastest)")
    }
    Tt <- length(Y) / N
    Y <- matrix(Y, nrow = N, ncol = Tt)
  }

  if(is.null(X)){
    X <- array(1, dim = c(N, Tt, 1))
  }
  if(length(dim(X)) != 3 || dim(X)[1] != N || dim(X)[2] != Tt){
    stop("error: X must be an N-by-T-by-p array aligned with coords (dim 1) and Y (dims 1-2)")
  }
  p <- dim(X)[3]

  if(nugget_status == 0){fix_nugget <- 0}
  if(nugget_status == 1){fix_nugget <- 1}

  if(tau.sq < 0){stop("error: tau.sq must be non-negative")}
  if(sigma.sq < 0){stop("error: sigma.sq must be non-negative")}
  if(phi < 0){stop("error: phi must be non-negative")}
  if(nu < 0){stop("error: nu must be non-negative")}
  if(gamma <= 0 || gamma >= 1){stop("error: gamma (the AR(1) autocorrelation) must be in (0, 1)")}

  coords <- round(coords, tol)
  Y <- round(Y, tol)

  ##Coords and ordering
  if(is.null(ordering)){
    if(order == "AMMD" && N < 65){stop("error: Number of data points must be atleast 65 to use AMMD")}
    if(order != "AMMD" && order != "Sum_coords"){
      stop("error: Please insert a valid ordering scheme choice given by 1 or 2.")
    }
    if(verbose == TRUE){
      cat(paste(("----------------------------------------"), collapse="   "), "\n"); cat(paste(("\tOrdering Coordinates"), collapse="   "), "\n")
    }
    if(order == "AMMD"){ord <- orderMaxMinLocal(coords)}
    if(order == "Sum_coords"){ord <- order(coords[,1] + coords[,2])}
  }
  if(!is.null(ordering)){
    ord <- ordering
  }

  coords <- coords[ord, , drop = FALSE]
  Y <- Y[ord, , drop = FALSE]
  X <- X[ord, , , drop = FALSE]

  ##Covariance model
  cov.model.names <- c("exponential","spherical","matern","gaussian")
  cov.model.indx <- which(cov.model == cov.model.names) - 1
  storage.mode(cov.model.indx) <- "integer"

  ##Initial values
  if(cov.model!="matern"){
    initiate <- c(sigma.sq, tau.sq, phi, gamma)
    names(initiate) <- c("sigma.sq", "tau.sq", "phi", "gamma")
  }else{
    initiate <- c(sigma.sq, tau.sq, phi, nu, gamma)
    names(initiate) <- c("sigma.sq", "tau.sq", "phi", "nu", "gamma")
  }

  ##Starting values: alpha/phi/nu use BRISC's own sqrt reparameterization (x -> x^2 in C++,
  ##enforcing positivity for the L-BFGS optimizer); gamma uses the logit transform (kept in
  ##(0,1), inverse is the sigmoid 1/(1+exp(-x)) applied back in C++).
  alpha.sq.starting <- sqrt(tau.sq/sigma.sq)
  phi.starting <- sqrt(phi)
  nu.starting <- sqrt(nu)
  gamma.logit.starting <- log(gamma/(1 - gamma))

  storage.mode(alpha.sq.starting) <- "double"
  storage.mode(phi.starting) <- "double"
  storage.mode(nu.starting) <- "double"
  storage.mode(gamma.logit.starting) <- "double"

  if(nugget_status == 0){alpha.sq.starting <- 0}

  ##Search type
  search.type.names <- c("brute", "tree", "cb")
  if(!search.type %in% search.type.names){
    stop("error: specified search.type '",search.type,"' is not a valid option; choose from ", paste(search.type.names, collapse=", ", sep="") ,".")
  }
  search.type.indx <- which(search.type == search.type.names)-1
  storage.mode(search.type.indx) <- "integer"

  ##Option for Multithreading if compiled with OpenMp support
  n.omp.threads <- as.integer(n_omp)
  storage.mode(n.omp.threads) <- "integer"

  ##type conversion. Y and X are flattened column-major (spatial index fastest, matching
  ##vec(Z) in overleaf/main.tex); R's own column-major storage already lays them out this way.
  y_vec <- as.double(Y)
  X_vec <- as.double(X)
  storage.mode(p) <- "integer"
  storage.mode(N) <- "integer"
  storage.mode(Tt) <- "integer"
  storage.mode(coords) <- "double"
  storage.mode(n.neighbors) <- "integer"
  storage.mode(verbose) <- "integer"
  storage.mode(eps) <- "double"
  storage.mode(fix_nugget) <- "double"

  p1 <- proc.time()

  ##estimation
  if(is.null(neighbor)){
    result <- .Call("BRISC_ST_estimatecpp", y_vec, X_vec, p, N, Tt, n.neighbors, coords, cov.model.indx,
                     alpha.sq.starting, phi.starting, nu.starting, gamma.logit.starting,
                     search.type.indx, n.omp.threads, verbose, eps, fix_nugget, PACKAGE = "BRISC")
  }

  if(!is.null(neighbor)){
    nnIndxLU <- neighbor$nnIndxLU
    storage.mode(nnIndxLU) <- "integer"
    CIndx <- neighbor$CIndx
    storage.mode(CIndx) <- "integer"
    D <- neighbor$D
    storage.mode(D) <- "double"
    d <- neighbor$d
    storage.mode(d) <- "double"
    nnIndx <- neighbor$nnIndx
    storage.mode(nnIndx) <- "integer"
    j <- neighbor$Length.D
    storage.mode(j) <- "integer"

    result_short <- .Call("BRISC_ST_estimateneighborcpp", y_vec, X_vec, p, N, Tt, n.neighbors, coords, cov.model.indx,
                           alpha.sq.starting, phi.starting, nu.starting, gamma.logit.starting,
                           search.type.indx, n.omp.threads, verbose, eps, fix_nugget,
                           nnIndxLU, CIndx, D, d, nnIndx, j, PACKAGE = "BRISC")
    result <- append(result_short, neighbor)
  }

  p2 <- proc.time()

  Theta <- result$theta
  if(cov.model!="matern"){
    names(Theta) <- c("sigma.sq", "tau.sq", "phi", "gamma")
  }else{
    names(Theta) <- c("sigma.sq", "tau.sq", "phi", "nu", "gamma")
  }

  Beta <- result$Beta
  for(i in seq_along(Beta)){
    names(Beta)[i] <- paste0("beta_", i)
  }

  llk <- -(result$log_likelihood + N*Tt + N*Tt*log(2*pi))/2

  result_list <- list()
  result_list$ord <- ord
  result_list$coords <- coords
  result_list$Y <- Y
  result_list$X <- X
  result_list$N <- N
  result_list$T <- Tt
  result_list$n.neighbors <- n.neighbors
  result_list$cov.model <- cov.model
  result_list$eps <- eps
  result_list$init <- initiate
  result_list$Beta <- Beta
  result_list$Theta <- Theta
  result_list$log_likelihood <- llk
  result_list$estimation.time <- p2 - p1
  result_list$BRISC_Object <- result
  class(result_list) <- "BRISC_ST_Out"
  result_list
}
